SWASTIK MINERALS & CHEMICAL - MOBILE APK BUILD

This project includes a GitHub Actions workflow that builds the Android APK online.

After uploading the project files to a GitHub repository:
1. Open the repository and tap the Actions tab.
2. Select "Build Swastik Minerals APK".
3. Tap "Run workflow" (if shown).
4. Wait for the workflow to finish with a green check.
5. Open the completed workflow run.
6. Under Artifacts, download "Swastik-Minerals-APK".
7. Extract the downloaded artifact ZIP; inside is app-debug.apk.

No Android Studio is required for this build.
