SWASTIK MINERALS & CHEMICAL — ANDROID STUDIO PROJECT

1. Open this folder in Android Studio.
2. Let Gradle sync.
3. Select Build > Build APK(s).
4. The APK will be generated under app/build/outputs/apk/debug/.

Application ID: com.swastikminerals.app
Version: 1.0
